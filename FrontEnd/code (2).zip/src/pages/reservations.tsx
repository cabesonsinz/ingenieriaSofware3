"use client"

/* Updated to use pure CSS classes */
import { Link } from "react-router-dom"
import { useAuth } from "../contexts/auth-context"
import { useData } from "../contexts/data-context"
import { useNotifications } from "../contexts/notifications-context"
import { Navigation } from "../components/navigation"
import "../styles/pages.css"

export default function ReservationsPage() {
  const { user } = useAuth()
  const { reservations, events, cancelReservation } = useData()
  const { addNotification } = useNotifications()

  const userReservations = reservations.filter((r) => r.userId === user?.id && r.status === "confirmed")

  const handleCancel = (reservationId: string) => {
    if (window.confirm("Are you sure you want to cancel this reservation?")) {
      try {
        cancelReservation(reservationId)
        addNotification("Reservation cancelled", "info")
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Failed to cancel reservation"
        addNotification(errorMessage, "error")
      }
    }
  }

  return (
    <>
      <Navigation />
      <main className="page-container">
        <div className="reservations-container">
          <div className="page-header mb-8">
            <h1 className="page-title">My Reservations</h1>
            <p className="page-subtitle">Manage your event bookings</p>
          </div>

          <div className="card" style={{ padding: "1.5rem", marginBottom: "2rem" }}>
            <h2 style={{ fontSize: "1.125rem", fontWeight: "600", marginBottom: "1rem" }}>Account Information</h2>
            <div
              style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: "1.5rem" }}
            >
              <div>
                <p className="text-sm" style={{ color: "var(--muted-foreground)", marginBottom: "0.25rem" }}>
                  Name
                </p>
                <p style={{ fontWeight: "600" }}>{user?.name}</p>
              </div>
              <div>
                <p className="text-sm" style={{ color: "var(--muted-foreground)", marginBottom: "0.25rem" }}>
                  Email
                </p>
                <p style={{ fontWeight: "600" }}>{user?.email}</p>
              </div>
              <div>
                <p className="text-sm" style={{ color: "var(--muted-foreground)", marginBottom: "0.25rem" }}>
                  Account Type
                </p>
                <p style={{ fontWeight: "600", textTransform: "capitalize" }}>{user?.role}</p>
              </div>
              <div>
                <p className="text-sm" style={{ color: "var(--muted-foreground)", marginBottom: "0.25rem" }}>
                  Member Since
                </p>
                <p style={{ fontWeight: "600" }}>
                  {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : "N/A"}
                </p>
              </div>
            </div>
          </div>

          <div>
            <h2 style={{ fontSize: "1.125rem", fontWeight: "600", marginBottom: "1rem" }}>Upcoming Events</h2>

            {userReservations.length === 0 ? (
              <div className="card" style={{ padding: "2rem", textAlign: "center" }}>
                <p style={{ color: "var(--muted-foreground)", marginBottom: "1rem" }}>No reservations yet</p>
                <Link to="/" className="btn btn-primary">
                  Browse Events
                </Link>
              </div>
            ) : (
              <div className="reservations-list">
                {userReservations.map((reservation) => {
                  const event = events.find((e) => e.id === reservation.eventId)
                  if (!event) return null

                  return (
                    <div key={reservation.id} className="reservation-card">
                      <div className="reservation-info">
                        <h3 className="reservation-title">{event.title}</h3>
                        <div className="reservation-details">
                          <div className="reservation-detail-item">
                            <span className="reservation-detail-label">Date</span>
                            <span className="reservation-detail-value">{event.date}</span>
                          </div>
                          <div className="reservation-detail-item">
                            <span className="reservation-detail-label">Time</span>
                            <span className="reservation-detail-value">{event.time}</span>
                          </div>
                          <div className="reservation-detail-item">
                            <span className="reservation-detail-label">Tickets</span>
                            <span className="reservation-detail-value">{reservation.ticketCount}</span>
                          </div>
                          <div className="reservation-detail-item">
                            <span className="reservation-detail-label">Total Price</span>
                            <span className="reservation-detail-value" style={{ color: "var(--primary)" }}>
                              ${reservation.totalPrice.toFixed(2)}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="reservation-actions">
                        <Link to={`/events/${event.id}`} className="reservation-action-btn">
                          View Event
                        </Link>
                        <button
                          onClick={() => handleCancel(reservation.id)}
                          className="reservation-action-btn reservation-cancel-btn"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </div>
      </main>
    </>
  )
}
